// Meta Ads Library Downloader - service-worker.js
// Recebe a URL do vídeo via mensagem e executa o download.

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.action !== "downloadVideo") {
        return false;
    }

    try {
        const url = message.url;

        if (!url) {
            console.error("[Meta Downloader]", "URL ausente na mensagem de download");
            return false;
        }

        const filename = `meta-ad-${Date.now()}.mp4`;

        chrome.downloads.download(
            {
                url: url,
                filename: filename,
                saveAs: false
            },
            (downloadId) => {
                if (chrome.runtime.lastError) {
                    console.error("[Meta Downloader]", chrome.runtime.lastError.message);
                    return;
                }
                console.log("[Meta Downloader] Download iniciado, id:", downloadId);
            }
        );
    } catch (error) {
        console.error("[Meta Downloader]", error);
    }

    return false;
});
