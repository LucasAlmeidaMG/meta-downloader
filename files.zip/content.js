// Meta Ads Library Downloader - content.js
// Localiza vídeos na página, cria botões de download e envia a URL para o service worker.

function getVideoUrl(video) {
    try {
        const url = video.currentSrc || video.src || "";
        if (url && url.trim().length > 0) {
            return url;
        }
        return null;
    } catch (error) {
        console.error("[Meta Downloader]", error);
        return null;
    }
}

function requestDownload(url) {
    try {
        chrome.runtime.sendMessage({
            action: "downloadVideo",
            url: url
        });
        console.log("[Meta Downloader] Download solicitado");
    } catch (error) {
        console.error("[Meta Downloader]", error);
    }
}

function createDownloadButton(video, url) {
    const button = document.createElement("button");
    button.className = "meta-downloader-button";
    button.type = "button";
    button.textContent = "⬇ Baixar vídeo";

    button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();

        const currentUrl = getVideoUrl(video) || url;
        if (!currentUrl) {
            console.error("[Meta Downloader]", "URL do vídeo indisponível no momento do clique");
            return;
        }
        requestDownload(currentUrl);
    });

    return button;
}

function processVideo(video) {
    try {
        // Evita duplicar botão se já processado
        if (video.dataset.metaDownloaderProcessed === "true") {
            return;
        }

        const url = getVideoUrl(video);

        if (!url) {
            // Ainda sem src/currentSrc, tenta novamente em uma próxima varredura
            return;
        }

        // Evita duplicar botão caso já exista um irmão criado para este vídeo
        const parent = video.parentElement;
        if (!parent) {
            return;
        }

        const alreadyHasButton = parent.querySelector(":scope > .meta-downloader-button");
        if (alreadyHasButton) {
            video.dataset.metaDownloaderProcessed = "true";
            return;
        }

        const button = createDownloadButton(video, url);

        // Garante que o container consiga posicionar o botão sobre/perto do vídeo
        if (getComputedStyle(parent).position === "static") {
            parent.style.position = "relative";
        }

        parent.appendChild(button);

        // Só marca como processado permanentemente quando a URL válida foi obtida
        video.dataset.metaDownloaderProcessed = "true";

        console.log("[Meta Downloader] Vídeo encontrado:", url);
    } catch (error) {
        console.error("[Meta Downloader]", error);
    }
}

function scanVideos() {
    try {
        const videos = document.querySelectorAll("video");
        videos.forEach((video) => {
            processVideo(video);
        });
    } catch (error) {
        console.error("[Meta Downloader]", error);
    }
}

// Varredura inicial
scanVideos();

// Observa mudanças no DOM (scroll infinito da Meta Ads Library)
const observer = new MutationObserver(() => {
    scanVideos();
});

observer.observe(document.body, {
    childList: true,
    subtree: true
});
